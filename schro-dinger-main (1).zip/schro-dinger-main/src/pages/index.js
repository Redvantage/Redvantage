import React from "react";
import ProjectTable from "../components/ProjectTable";
import UpcomingPools from "../components/upcomingPools";

const Home = () => {
  return (
    <div className="h-fit">
      <UpcomingPools />
      <ProjectTable />
    </div>
  );
};

export default Home;
