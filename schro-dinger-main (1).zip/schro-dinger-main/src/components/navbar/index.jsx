import React from "react";

const Navbar = () => {
  return (
    <nav className="flex items-center justify-between py-6 px-4 lg:px-16 xl:px-32 ">
      <div>
        <img className="" src="./logo.png" alt="" />
      </div>
      <div>
        <button className="rounded hover:bg-[#FFDF0C] hover:text-black py-2 px-4 text-[#FFDF0C] border border-[#FFDF0C]">
          Connect Wallet
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
